
<?php
include 'datetime.php';
include 'connection.php';


$presentqury =mysqli_query($server, "SELECT
  COUNT(attleave.Attend)
FROM attleave
  INNER JOIN employee
    ON attleave.Employee_Nic = employee.Nic 
WHERE employee.Status = 'para' and
attleave.Attend = '1' and attleave.date = '$date3'");

while($row = mysqli_fetch_array($presentqury)){
      $present = $row[0];
      
}
// echo $present." Employees came today..";

$absentqury =mysqli_query($server, "SELECT
  COUNT(attleave.Attend)
FROM attleave
  INNER JOIN employee
    ON attleave.Employee_Nic = employee.Nic 
WHERE employee.Status = 'para' and
attleave.Attend = '0' and attleave.date = '$date3' ");
while($row1 = mysqli_fetch_array($absentqury)){
      $absent = $row1[0];
     // echo $absent." Employees Absent today.";
}

$tot = $absent + $present;

$json = '{"a":'.$present.',"b":'.$absent.',"c":'.$tot.'}';


echo $json;


?>
